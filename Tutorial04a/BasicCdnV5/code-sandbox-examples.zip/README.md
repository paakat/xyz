# Basic Example

A simple [create-react-app](CRA-README.md) setup, showcasing one of the latest React-Bootstrap components!
